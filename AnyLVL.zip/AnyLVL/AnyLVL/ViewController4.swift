//
//  ViewController4.swift
//  AnyLVL
//
//  Created by Roman Kharchenko on 08/08/2019.
//  Copyright © 2019 Roman Kharchenko. All rights reserved.
//

import UIKit

class ViewController4: ViewController2 {
    
   
    override func viewDidLoad() {
        super.viewDidLoad()

        self.ourButton.frame = CGRect(x: 90, y: 450, width: 200, height: 70)
        self.ourButton.setTitle("Узнать стоимость", for: .normal)
  
    }

    // Главная кнопка ( фукнция при нажатии )
    @objc override func alert (sender:UIButton) {
        ourAlert(title: "Сколько игр?", message: "Пример: 2", style: .alert)
        ourTextField.text = ""
        ourTextField2.text = ""
     
    }

    // Вызов Алерта
    override func ourAlert ( title:String, message:String, style:UIAlertController.Style ) {
        let buttonAlert = UIAlertController(title: title, message: message, preferredStyle: style)
        let buttonAction = UIAlertAction(title: "Подтвердить", style: .default) { (buttonAction) in
            
            // Переменные
            let text = buttonAlert.textFields?.first
            let text2 = (text?.text)!
            let text3 = Int(text2) ?? 0
            let coast:Double = Double(text3) * 500
            var day = 0
            
            //Считаем дни
            if text3 <= 2 {
                day += 2
            } else if text3 <= 5 && text3 >= 5 {
                day += 3
            }
            
            
            
            //  Алгоритм проверки + работы Switch и тд
            if self.ourSwitch.isOn {
                if (text3 != 0) && (text3 <= 5) {
                    day -= 1
                    self.ourTextField.text! += ("Цена: \(coast * 1.2 ) рублей")
                    self.ourTextField2.text! += ("Срок: \(day) дня")
                } else {
                    self.ourTextField.text! += ("Некорректный ввод!")
                    self.ourTextField2.text! += ("")
                    
                    
                }
                
            } else {
                if (text3 != 0) && (text3 <= 5){
                    
                    self.ourTextField.text! += ("Цена: \(coast) рублей")
                    self.ourTextField2.text! += ("Срок: \(day) дня")
                } else {
                    self.ourTextField.text! += ("Некорректный ввод!")
                    self.ourTextField2.text! += ("")
                   
                    
                }
            }
        }
        buttonAlert.addTextField { (textField) in
        }
        
        buttonAlert.addAction(buttonAction)
        self.present(buttonAlert, animated: true, completion: nil)
        
    }
}
