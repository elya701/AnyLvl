//
//  ViewController4.swift
//  AnyLVL
//
//  Created by Roman Kharchenko on 08/08/2019.
//  Copyright © 2019 Roman Kharchenko. All rights reserved.
//

import UIKit

class ViewController4: UIViewController {
    

    let ourButton3 = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
    assignbackground()
        
     //Кнопка
        
        self.ourButton3.frame = CGRect(x: 5, y: 625, width: 85, height: 30)
        self.ourButton3.backgroundColor = UIColor.gray
        self.ourButton3.setTitle("Назад", for: .normal)
        self.view.addSubview(ourButton3)
        
        self.ourButton3.addTarget(self, action: #selector(alert3(sender:)) , for: .touchUpInside)
    }
    

    func assignbackground(){
        let background = UIImage(named: "background.jpg")
        
        var imageView : UIImageView!
        imageView = UIImageView(frame: view.bounds)
        imageView.contentMode =  UIView.ContentMode.scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = background
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.sendSubviewToBack(imageView)
    }
    @objc func alert3 (sender:UIButton) {
        let viewController = ViewController()
        self.present(viewController, animated: true, completion: nil)
}
}

    
    
