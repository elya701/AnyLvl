//
//  ViewController4.swift
//  AnyLVL
//
//  Created by Roman Kharchenko on 08/08/2019.
//  Copyright © 2019 Roman Kharchenko. All rights reserved.
//

import UIKit

class ViewController3: ViewController2 {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.ourButton.setTitle("Рассчитать калибровку", for: .normal)
    }
    
    @objc override func alert (sender:UIButton) {
        ourAlert(title: "Предыдущий рейтинг", message: "Если был, иначе 0", style: .alert)
        ourTextField.text = ""
        ourTextField2.text = ""
        ourTextField4.text = ("")
    }
    
    override func ourAlert ( title:String, message:String, style:UIAlertController.Style ) {
        let buttonAlert = UIAlertController(title: title, message: message, preferredStyle: style)
        let buttonAction = UIAlertAction(title: "Подтвердить", style: .default) { (buttonAction) in
            
            // Переменные
            let text = buttonAlert.textFields?.first
            let text2 = (text?.text)!
            let text3 = Int(text2) ?? 0
            let coast:Double = Double(text3) * 3.25
            var mmr = 0
            var day = 0
            
            //Считаем дни
            if text3 < 2001 {
                day += 2
            } else if text3 < 5001 && text3 > 2000 {
                day += 3
            } else if text3 < 7501 && text3 > 5000 {
                day += 4
            } else {
                day += 5
            }
            
            // Алгоритм калибровки
            if text3 != 0 {
                if text3 <= 2500 {
                    mmr = text3 + 1500
                } else if text3 <= 5000 && text3 > 2500 {
                    mmr = text3 + 1000
                } else if text3 <= 7500 && text3 > 5000 {
                    mmr = text3 + 600
                } else {
                    mmr = text3 + 350
                }
            }
            else {
                mmr = 0
            }
            
            //  Алгоритм проверки ММР + работы Switch и тд
            
            if self.ourSwitch.isOn {
                if (text3 <= 10000) {
                    day -= 1
                    self.ourTextField.text! += ("Твой ММР будет \(mmr)")
                    self.ourTextField2.text! += ("Цена: \(coast * 1.2) рублей")
                    self.ourTextField4.text! += ("Срок: \(day) дня")
                } else {
                    self.ourTextField.text! += ("Некорректный ММР!")
                    self.ourTextField2.text! += ("")
                    self.ourTextField4.text! += ("")
                    
                }
                
            } else {
                if (text3 <= 10000){
                    self.ourTextField.text! += ("Твой ММР будет \(mmr)")
                    self.ourTextField2.text! += ("Цена: \(coast) рублей")
                    self.ourTextField4.text! += ("Срок: \(day) дня")
                } else {
                    self.ourTextField.text! += ("Некорректный ММР!")
                    self.ourTextField2.text! += ("")
                    self.ourTextField4.text! += ("")
                    
                }
            }
        }
        
        
        buttonAlert.addTextField { (textField) in
        }
        
        buttonAlert.addAction(buttonAction)
        self.present(buttonAlert, animated: true, completion: nil)
    }
    
}
